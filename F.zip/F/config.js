/* Anu Anu Yang Dibutuhkan */

const fs = require('fs'); 
const chalk = require('chalk');
/*-------------------------------*/

/* GANTI DENGAN IDENTITAS KAMU! */

global.owner = ['6283171710709', '6282128475388']; // Nomor Yang Akan Menjadi Owner
global.mods = ['6283171710709']; // Nomor Yang Akan Menjadi Moderator
global.prems = ['6283171710709', '6282128475388']; // Pengguna Premium
global.nameowner = '𝙼𝚁. Ｄ'; // Terserah
global.numberowner = '6283171710709'; // Masukkan Aja..
global.mail = 'dapitt@onee.eu.org'; // Emailmu
global.gc = 'https://chat.whatsapp.com/Ln2vHjRrRayAbzalRMB56r'; // Kalo Ada
global.instagram = 'https://instagram.com/davidpangrib001'; // Terserah
global.wm = '\n\n\nＤ\n\n\n'; // Footer
global.wait = '_Wait.. >-<_'; // Message
global.eror = '_Error ×~×_'; // Message
global.stiker_wait = '_Wait a Moment.._ •//•'; // Message
global.packname = ''; // Packname WhatsApp's Sticker
global.author = '- One BotZ -\n\n\n(c) 2023\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n'; // Author WhatsApp's Sticker
/*----------------------*/

// Thumbnail
global.gambar = JSON.parse(fs.readFileSync('./src/thumb.json'));
global.thumbnail = gambar[Math.floor(Math.random() * gambar.length)];

/* INI WAJIB DI ISI! */
global.lol = 'GataDios'; //Daftar Di api.lolhuman.xyz
global.btc = 'uevW5rkB'; // Daftar terlebih dahulu https://api.botcahx.live
global.lann = 'YOb75QGn'; // Daftar terlebih dahulu https://api.betabotz.org

global.APIs = {
  btc: 'https://api.botcahx.live',
};
global.APIKeys = {
  'https://api.botcahx.live': 'uevW5rkB',
};

let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.redBright("Update 'config.js'"));
  delete require.cache[file];
  require(file);
});
