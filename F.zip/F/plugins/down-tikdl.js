const https = require('https');

let handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0]) {
    throw `Masukkan URL!\n\ncontoh:\n${usedPrefix + command} https://vm.tiktok.com/ZSND9YYr2/`;
  }
  try {
    if (!args[0].match(/tiktok/gi)) {
      throw `URL Tidak Ditemukan!`;
    }
    m.reply('Sedang Mengunduh..');
    const api = await fetchTikTokData(args[0]);

    const { 
      video, 
      title,
      thumbnail, 
      title_audio,
      audio
    } = api.result;

    await conn.sendFile(m.chat, video, 'tiktok.mp4', `*Tiktok Downloader*\n${title}`, m);

    await conn.sendMessage(m.chat, {
      audio: {
        url: audio
      },
      mimetype: 'audio/mpeg',
      contextInfo: {
        externalAdReply: {
          title: `${title_audio}`,
          body: '',
          thumbnailUrl: 'https://i2.wp.com/a.uguu.se/VFLfKYmT.jpg',
          sourceUrl: audio,
          mediaType: 1,
          showAdAttribution: true,
          renderLargerThumbnail: true
        }
      }
    });
  } catch (e) {
    console.log(e);
    throw `Terjadi Kesalahan!\n${e}`;
  }
};

const fetchTikTokData = async (url) => {
  return new Promise((resolve, reject) => {
    https.get(`https://api.botcahx.live/api/dowloader/tiktok?url=${url}&apikey=${btc}`, response => {
      let data = '';
      response.on('data', chunk => {
        data += chunk;
      });
      response.on('end', () => {
        resolve(JSON.parse(data));
      });
    }).on('error', reject);
  });
};

handler.help = ['tikdl'];
handler.command = /^(tikdl)$/i;
handler.tags = ['downloader'];
handler.limit = true;
handler.group = false;
handler.premium = false;
handler.owner = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.private = false;

module.exports = handler;