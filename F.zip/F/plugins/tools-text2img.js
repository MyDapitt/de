const fetch = require('node-fetch');

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) throw `• *Masukan Detailnya*
Contoh: .text2img cat,fish\n\n_Jangan masukin yang aneh-aneh.._`;
  try {
    conn.reply(m.chat, wait, m)
    const res = await fetch(`https://api.botcahx.live/api/maker/text2img?text=${text}&apikey=${btc}`).then(res => res.buffer());
    conn.sendFile(m.chat, res, 'res.png', `Result: ${text}`, m);
  } catch (error) {
    m.reply(`*• Error*\n\n${error}`);
  }
};

handler.command = handler.help = ['text2img'];
handler.tags = ['tools'];
handler.limit = true;
module.exports = handler;