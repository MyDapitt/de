const fetch = require('node-fetch');
const FormData = require('form-data');
const { fromBuffer } = require('file-type');

/**
 * Upload image to telegra.ph
 * Supported mimetype:
 * - `image/jpeg`
 * - `image/jpg`
 * - `image/png`
 * @param {Buffer} buffer Image Buffer
 */
module.exports = async buffer => {
  const { ext } = await fromBuffer(buffer);
  let form = new FormData();
  form.append('file', buffer, { filename: 'tmp.' + ext });
  let res = await fetch('https://drive.aeona.net/api/upload.php', {
    method: 'POST',
    body: form
  });
  let resp = await res.json();
  return resp.result
};