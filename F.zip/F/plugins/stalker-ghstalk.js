let fetch = require('node-fetch')

let handler = async (m, { text, usedPrefix, command }) => {
    if (!text) throw `*Example:* ${usedPrefix + command} BOTCAHX`   
    try {     
        let json = await fetch(`https://api.github.com/users/${text}`).then(res => res.json());
        let avatar = json.avatar_url
        let username = json.login
        let nid = json.node_id
        let hm = json.html_url
        let follower = json.followers
        let following = json.following
        let blog = json.blog
        let type = json.type
        let bio = json.bio
        let repo_total = json.public_repos
        
        let caption = ` *- G I T H U B  S T A L K*
*- Username:* ${text}
*- Type:* ${type}
*- Node ID:* ${nid}
*- Blog:* ${blog}  
*- Follower(s):* ${follower} 
*- Following:* ${following}
*- Repository Total:* ${repo_total}
        
${bio}
        
        `
        conn.relayMessage(m.chat, {
            extendedTextMessage: {
                text: caption,
                contextInfo: {
                    externalAdReply: {
                        title: username,
                        mediaType: 1,
                        previewType: 0,
                        renderLargerThumbnail: true,
                        thumbnailUrl: avatar,
                        sourceUrl: hm
                    }
                }, mentions: [m.sender]
            }
        }, {})
    } catch (e) {     
        throw `Error: ${error}`
    }
}
handler.help = ['ghstalk <username>']
handler.tags = ['stalk']
handler.command = /^(ghstalk|githubstalk)$/i
handler.limit = true

module.exports = handler