let fetch = require('node-fetch')

let handler = async (m, { conn, command }) => {
    let api1 = `https://api.ibeng.tech/api/asupan/image/${command}?apikey=sqo7zssHBX`
    let buffer = await fetch(api1)
        .then(res => res.buffer())
    conn.sendFile(m.chat, buffer, 'image.jpeg', `Random ${command}`, m)
}

handler.command = ['china','malaysia','korean','vietnam','thailand','japan','indonesia']
handler.tags = ['downloader']

module.exports = handler
