## RT BOT

<center><img src="https://i1.wp.com/a.uguu.se/VGlWXzlH.jpg"/></center>

**New UPDATE**
- Now, This Script Is Using Multi Auth Session(s). To using this feature, start this script using command:
``` bash
node . --pairing
```
- QR on terminal has been fixed
- Message To Console Has Been Fixed
- Fix Downloader 
- Pairing code has been added to connect without scan
- Added web output to run on <a href="https://render.com/">Render</a>, etc..

  ## IMPORTANT!!
  
- It is mandatory to fill in the apikey first before using the script.
- DOES NOT SUPPORT TERMUX OR PANEL missing browser features puppeteer, express and other needs.
  
- This Script Is Using This Rest API from <a href="https://api.botcahx.live">BOTCAHX</a> <a href="https://api.betabotz.org">Lann</a>
# What to edit?
***Edit the config.js file***
-  Bot's Owner, Moderator Number, and your name
- Your Bot Identity
- global.btc = Get Keys and Sign Up <a href="https://api.botcahx.live">Here</a>
- global.lann = Get Keys and Sign Up <a href="https://api.betabotz.org">Here</a>

### `Render`

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://dashboard.render.com/blueprint/new?repo=https%3A%2F%2Fgithub.com%2FMyDapitt%2Frt-bot)


## Run On Heroku

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/mydapitt/rt-bot)

**Heroku Buildpack**

```bash
* heroku/nodejs
* https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest.git
* https://github.com/clhuang/heroku-buildpack-webp-binaries.git
```

## For Windows User (Windows 10+)

* Download & Install GIT [`Click Here`](https://git-scm.com/downloads)
* Downloas & Install NodeJS [`Click Here`](https://nodejs.org/id/download)
* Download & Install FFmpeg [`Click Here`](https://ffmpeg.org/download.html) (**Don't forget for adding the FFmpeg to PATH environment**)
* Download & Install ImageMagick [`Click Here`](https://imagemagick.org/script/download.php)

```bash
git clone https://github.com/MyDapitt/rt-bot
cd rt-bot
npm install
node . --pairing
```


##### All Contributors
<a href="https://github.com/BOTCAHX"><img src="https://github.com/BOTCAHX.png?size=100" width="100" height="100"></a> | [![Erlan](https://github.com/ERLANRAHMAT.png?size=100)](https://github.com/ERLANRAHMAT) 
---|---
[Tio](https://github.com/BOTCAHX)  | [Erlan](https://github.com/ERLANRAHMAT)
Recode | Contributor |

##### Special Thanks To
<!--[![Nurutomo](https://github.com/Nurutomo.png?size=100)](https://github.com/Nurutomo)
[![BochilGaming](https://github.com/BochilGaming.png?size=100)](https://github.com/BochilGaming)
[![adiwajshing/Baileys](https://github.com/adiwajshing.png?size=100)](https://github.com/adiwajshing)-->
<a href="https://github.com/BochilGaming"><img src="https://github.com/BochilGaming.png?size=100" width="100" height="100"></a> | [![NURUTOMO](https://github.com/Nurutomo.png?size=100)](https://github.com/Nurutomo) 
---|---
[Bochilgaming](https://github.com/BochilGaming)  | [Nurutomo](https://github.com/Nurutomo)
sepuh | sepuh |
