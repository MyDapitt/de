node -v
node . --autoread --autoread 'mongodb+srv://David0l1:36011@cluster0.rpgbtss.mongodb.net/?retryWrites=true&w=majority'
